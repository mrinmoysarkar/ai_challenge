// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#ifndef _AFRL_CMASI_SEARCHAI_ENTIRESERIESHEADER_H_
#define _AFRL_CMASI_SEARCHAI_ENTIRESERIESHEADER_H_

#include "afrl/cmasi/searchai/HazardZone.h"
#include "afrl/cmasi/searchai/HazardZoneDetection.h"
#include "afrl/cmasi/searchai/HazardZoneEstimateReport.h"
#include "afrl/cmasi/searchai/RecoveryPoint.h"
#include "afrl/cmasi/searchai/HazardZoneChangeCommand.h"
#include "afrl/cmasi/searchai/HazardSensorConfiguration.h"
#include "afrl/cmasi/searchai/HazardSensorState.h"
#include "afrl/cmasi/searchai/HazardType.h"
#include "afrl/cmasi/searchai/SEARCHAIEnum.h"


#endif //_AFRL_CMASI_SEARCHAI_ENTIRESERIESHEADER_H_
