// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#include <cassert>
#include <sstream>
#include <iomanip>
#include "afrl/cmasi/searchai/HazardZoneChangeCommand.h"


namespace afrl {
namespace cmasi {
namespace searchai {


   // Subscription string is namespace separated by '.' followed by type name
   const std::string HazardZoneChangeCommand::Subscription = "afrl.cmasi.searchai.HazardZoneChangeCommand";
   const std::string HazardZoneChangeCommand::TypeName = "HazardZoneChangeCommand";
   const std::string HazardZoneChangeCommand::SeriesName = "SEARCHAI";
   const int64_t HazardZoneChangeCommand::SeriesId = 6000273900112986441LL;
   const uint16_t HazardZoneChangeCommand::SeriesVersion = 5;
   const uint32_t HazardZoneChangeCommand::TypeId = 5;
   
   bool isHazardZoneChangeCommand(avtas::lmcp::Object* obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 5) return false;
      return true;
   }
   
   bool isHazardZoneChangeCommand(std::shared_ptr<avtas::lmcp::Object>& obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 5) return false;
      return true;
   }
   
   std::vector< std::string > HazardZoneChangeCommandDescendants()
   {
       std::vector< std::string > descendants;
       

       return descendants;
   }
   
   HazardZoneChangeCommand::HazardZoneChangeCommand(void) : avtas::lmcp::Object()
   {
      __ZoneID = 0;
      __GrowthRate = 0.f;
      __TranslationRate = 0.f;
      __TranslationDirection = 0.f;

   }
     
   HazardZoneChangeCommand::HazardZoneChangeCommand(const HazardZoneChangeCommand &that) : avtas::lmcp::Object(that)
   {
        __ZoneID = that.__ZoneID;
        __GrowthRate = that.__GrowthRate;
        __TranslationRate = that.__TranslationRate;
        __TranslationDirection = that.__TranslationDirection;

   }
   
   HazardZoneChangeCommand & HazardZoneChangeCommand::operator=(const HazardZoneChangeCommand &that)
   {
      if (this != &that)
      {
         avtas::lmcp::Object::operator=(that);

         __ZoneID = that.__ZoneID;
         __GrowthRate = that.__GrowthRate;
         __TranslationRate = that.__TranslationRate;
         __TranslationDirection = that.__TranslationDirection;

      }
      return *this;
   }

   HazardZoneChangeCommand* HazardZoneChangeCommand::clone() const
   {
        return new HazardZoneChangeCommand(*this);
   }
   
   HazardZoneChangeCommand::~HazardZoneChangeCommand(void)
   {

   }
  
   void HazardZoneChangeCommand::pack(avtas::lmcp::ByteBuffer & buf) const
   {
      // Call parent's pack method
      avtas::lmcp::Object::pack(buf);
      // Copy the class into the buffer
      buf.putUInt(__ZoneID);
      buf.putFloat(__GrowthRate);
      buf.putFloat(__TranslationRate);
      buf.putFloat(__TranslationDirection);

   }
   
   void HazardZoneChangeCommand::unpack(avtas::lmcp::ByteBuffer & buf)
   {
      // Call parent's unpack method
      avtas::lmcp::Object::unpack(buf);
      // Copy the buffer into the class
      __ZoneID = buf.getUInt();
      __GrowthRate = buf.getFloat();
      __TranslationRate = buf.getFloat();
      __TranslationDirection = buf.getFloat();

   }

   uint32_t HazardZoneChangeCommand::calculatePackedSize(void) const
   {
      uint32_t size = 0;
      size += avtas::lmcp::Object::calculatePackedSize();
      size += sizeof(uint32_t);
      size += sizeof(float);
      size += sizeof(float);
      size += sizeof(float);

      return size;
   }

   std::string HazardZoneChangeCommand::toString(int32_t depth) const
   {
      std::string indent(depth*3, ' ');
      std::ostringstream oss;
      oss << std::setprecision(15);
      oss << indent << "Object ( HazardZoneChangeCommand ) {\n";
      indent = std::string((++depth)*3, ' ');
      oss << indent << "ZoneID (uint32_t) = " << __ZoneID << "\n";
      oss << indent << "GrowthRate (float) = " << __GrowthRate << "\n";
      oss << indent << "TranslationRate (float) = " << __TranslationRate << "\n";
      oss << indent << "TranslationDirection (float) = " << __TranslationDirection << "\n";

      indent = std::string((--depth)*3, ' ');
      oss << indent << "}\n";
      return oss.str();
   }

   std::string HazardZoneChangeCommand::toXML(int32_t depth)
   {
      std::string ws(depth*3, ' ');
      std::ostringstream str;
      str << std::setprecision(15);
      str << ws << "<HazardZoneChangeCommand Series=\"SEARCHAI\">\n";
      str << ws << "   <ZoneID>" << __ZoneID << "</ZoneID>\n";
      str << ws << "   <GrowthRate>" << __GrowthRate << "</GrowthRate>\n";
      str << ws << "   <TranslationRate>" << __TranslationRate << "</TranslationRate>\n";
      str << ws << "   <TranslationDirection>" << __TranslationDirection << "</TranslationDirection>\n";
      str << ws << "</HazardZoneChangeCommand>\n";

      return str.str();
   }

   bool HazardZoneChangeCommand::operator==(const HazardZoneChangeCommand & that)
   {
      if( avtas::lmcp::Object::operator!=(that) )
      {
          return false;
      }
      if(__ZoneID != that.__ZoneID) return false;
      if(__GrowthRate != that.__GrowthRate) return false;
      if(__TranslationRate != that.__TranslationRate) return false;
      if(__TranslationDirection != that.__TranslationDirection) return false;
      return true;

   }

   bool HazardZoneChangeCommand::operator!=(const HazardZoneChangeCommand & that)
   {
      return( !(operator==(that)) );
   }

   HazardZoneChangeCommand& HazardZoneChangeCommand::setZoneID(const uint32_t val)
   {
      __ZoneID = val;
      return *this;
   }

   HazardZoneChangeCommand& HazardZoneChangeCommand::setGrowthRate(const float val)
   {
      __GrowthRate = val;
      return *this;
   }

   HazardZoneChangeCommand& HazardZoneChangeCommand::setTranslationRate(const float val)
   {
      __TranslationRate = val;
      return *this;
   }

   HazardZoneChangeCommand& HazardZoneChangeCommand::setTranslationDirection(const float val)
   {
      __TranslationDirection = val;
      return *this;
   }


} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl

