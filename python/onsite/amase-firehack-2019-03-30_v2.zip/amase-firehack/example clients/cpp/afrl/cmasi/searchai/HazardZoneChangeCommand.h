// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#ifndef _AFRL_CMASI_SEARCHAI_HAZARDZONECHANGECOMMAND_H_
#define _AFRL_CMASI_SEARCHAI_HAZARDZONECHANGECOMMAND_H_

#include <cstdint>
#include <memory>
#include <vector>
#include "avtas/lmcp/Factory.h"
#include "SEARCHAIEnum.h"
#include "avtas/lmcp/Object.h"



namespace afrl {
namespace cmasi {
namespace searchai {


   bool isHazardZoneChangeCommand(avtas::lmcp::Object* obj);
   bool isHazardZoneChangeCommand(std::shared_ptr<avtas::lmcp::Object>& obj);
   std::vector< std::string > HazardZoneChangeCommandDescendants();
   
   class HazardZoneChangeCommand : public avtas::lmcp::Object {
   public:
      static const std::string Subscription;
      static const std::string TypeName;
      static const std::string SeriesName;
      static const int64_t SeriesId;
      static const uint16_t SeriesVersion;
      static const uint32_t TypeId;
      
      // Constructor
      HazardZoneChangeCommand(void);

      // Copy Constructor
      HazardZoneChangeCommand(const HazardZoneChangeCommand &that);

      // Assignment Operator
      HazardZoneChangeCommand & operator=(const HazardZoneChangeCommand &that);

      // Destructor
      virtual ~HazardZoneChangeCommand(void);

      // Equals overload
      bool operator==(const HazardZoneChangeCommand & that);
      bool operator!=(const HazardZoneChangeCommand & that);

      // Serializes calling object into a ByteBuffer.
      virtual void pack(avtas::lmcp::ByteBuffer & buf) const;

      // Deserializes ByteBuffer into calling object.
      virtual void unpack(avtas::lmcp::ByteBuffer & buf);

      // Calculates current object size in bytes
      virtual uint32_t calculatePackedSize(void) const;

      // Creates a copy of this object and returns a pointer to it.
      virtual HazardZoneChangeCommand* clone() const;

      // Returns string representation of object
      virtual std::string toString(int32_t depth=0) const;

      // Returns an XML string representation of the object.
      virtual std::string toXML(int32_t depth=0);

      // Returns object type id
      virtual uint32_t getLmcpType(void) const { return TypeId; }
	  
      // Returns object type name string
      virtual std::string getLmcpTypeName(void) const { return TypeName; }
	  
      // Returns object type name string with full namespace prepended, same as subscription name
      virtual std::string getFullLmcpTypeName(void) const { return Subscription; }

      // Returns series name string
      virtual std::string getSeriesName(void) const { return SeriesName; }

      // gets the series name as a long value
      virtual int64_t getSeriesNameAsLong(void) const { return SeriesId; }

      //gets the version number of the series
      virtual uint16_t getSeriesVersion(void) const { return SeriesVersion; }

      // Accessors and Modifiers
      /** ID of zone to control. If zero, then this is treated as a default command for all zones not governed by a zone-specific message. (Units: None)*/
      uint32_t getZoneID(void) const { return __ZoneID; }
      HazardZoneChangeCommand& setZoneID(const uint32_t val);

      /** The rate of growth of the zone. How this affects the zone depends on its geometry type. (Units: m/s)*/
      float getGrowthRate(void) const { return __GrowthRate; }
      HazardZoneChangeCommand& setGrowthRate(const float val);

      /** Translation rate of the zone across the scenario area. (Units: m/s)*/
      float getTranslationRate(void) const { return __TranslationRate; }
      HazardZoneChangeCommand& setTranslationRate(const float val);

      /** True direction of translation of the zone. (Units: degrees)*/
      float getTranslationDirection(void) const { return __TranslationDirection; }
      HazardZoneChangeCommand& setTranslationDirection(const float val);



   protected:
      /** ID of zone to control. If zero, then this is treated as a default command for all zones not governed by a zone-specific message. */
      uint32_t __ZoneID;
      /** The rate of growth of the zone. How this affects the zone depends on its geometry type. */
      float __GrowthRate;
      /** Translation rate of the zone across the scenario area. */
      float __TranslationRate;
      /** True direction of translation of the zone. */
      float __TranslationDirection;

   };

} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl


#endif // _AFRL_CMASI_SEARCHAI_HAZARDZONECHANGECOMMAND_H_
