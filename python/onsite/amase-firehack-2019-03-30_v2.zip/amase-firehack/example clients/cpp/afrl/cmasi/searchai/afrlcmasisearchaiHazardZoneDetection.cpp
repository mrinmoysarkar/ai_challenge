// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#include <cassert>
#include <sstream>
#include <iomanip>
#include "afrl/cmasi/searchai/HazardZoneDetection.h"
#include "afrl/cmasi/Waypoint.h"
#include "afrl/cmasi/PathWaypoint.h"


namespace afrl {
namespace cmasi {
namespace searchai {


   // Subscription string is namespace separated by '.' followed by type name
   const std::string HazardZoneDetection::Subscription = "afrl.cmasi.searchai.HazardZoneDetection";
   const std::string HazardZoneDetection::TypeName = "HazardZoneDetection";
   const std::string HazardZoneDetection::SeriesName = "SEARCHAI";
   const int64_t HazardZoneDetection::SeriesId = 6000273900112986441LL;
   const uint16_t HazardZoneDetection::SeriesVersion = 5;
   const uint32_t HazardZoneDetection::TypeId = 2;
   
   bool isHazardZoneDetection(avtas::lmcp::Object* obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 2) return false;
      return true;
   }
   
   bool isHazardZoneDetection(std::shared_ptr<avtas::lmcp::Object>& obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 2) return false;
      return true;
   }
   
   std::vector< std::string > HazardZoneDetectionDescendants()
   {
       std::vector< std::string > descendants;
       

       return descendants;
   }
   
   HazardZoneDetection::HazardZoneDetection(void) : avtas::lmcp::Object()
   {
      __DetectedLocation = new afrl::cmasi::Location3D();
      __SensorPayloadID = 0;
      __DetectingEnitiyID = 0;
      __DetectedHazardZoneType = afrl::cmasi::searchai::HazardType::Undefined;

   }
     
   HazardZoneDetection::HazardZoneDetection(const HazardZoneDetection &that) : avtas::lmcp::Object(that)
   {
        __DetectedLocation = that.__DetectedLocation == nullptr ? nullptr : that.__DetectedLocation->clone();
        __SensorPayloadID = that.__SensorPayloadID;
        __DetectingEnitiyID = that.__DetectingEnitiyID;
        __DetectedHazardZoneType = that.__DetectedHazardZoneType;

   }
   
   HazardZoneDetection & HazardZoneDetection::operator=(const HazardZoneDetection &that)
   {
      if (this != &that)
      {
         avtas::lmcp::Object::operator=(that);
         if (__DetectedLocation != nullptr) delete __DetectedLocation;

         __DetectedLocation = that.__DetectedLocation == nullptr ? nullptr : that.__DetectedLocation->clone();
         __SensorPayloadID = that.__SensorPayloadID;
         __DetectingEnitiyID = that.__DetectingEnitiyID;
         __DetectedHazardZoneType = that.__DetectedHazardZoneType;

      }
      return *this;
   }

   HazardZoneDetection* HazardZoneDetection::clone() const
   {
        return new HazardZoneDetection(*this);
   }
   
   HazardZoneDetection::~HazardZoneDetection(void)
   {
      if (__DetectedLocation != nullptr) delete __DetectedLocation;

   }
  
   void HazardZoneDetection::pack(avtas::lmcp::ByteBuffer & buf) const
   {
      // Call parent's pack method
      avtas::lmcp::Object::pack(buf);
      // Copy the class into the buffer
      assert(__DetectedLocation != nullptr);
      avtas::lmcp::Factory::putObject( (avtas::lmcp::Object*) __DetectedLocation, buf);
      buf.putUInt(__SensorPayloadID);
      buf.putUInt(__DetectingEnitiyID);
      buf.putInt( (int32_t) __DetectedHazardZoneType);

   }
   
   void HazardZoneDetection::unpack(avtas::lmcp::ByteBuffer & buf)
   {
      // Call parent's unpack method
      avtas::lmcp::Object::unpack(buf);
      // Copy the buffer into the class
      {
         if (__DetectedLocation != nullptr) delete __DetectedLocation;
         __DetectedLocation = nullptr;
         if (buf.getBool())
         {
            int64_t series_id = buf.getLong();
            uint32_t msgtype = buf.getUInt();
            uint16_t version = buf.getUShort();
            __DetectedLocation = (afrl::cmasi::Location3D*) avtas::lmcp::Factory::createObject( series_id, msgtype, version );
            if (__DetectedLocation != nullptr) __DetectedLocation->unpack(buf);
            else assert(__DetectedLocation != nullptr);
         }
      }
      __SensorPayloadID = buf.getUInt();
      __DetectingEnitiyID = buf.getUInt();
      __DetectedHazardZoneType = (afrl::cmasi::searchai::HazardType::HazardType) buf.getInt();

   }

   uint32_t HazardZoneDetection::calculatePackedSize(void) const
   {
      uint32_t size = 0;
      size += avtas::lmcp::Object::calculatePackedSize();
      size += (__DetectedLocation != nullptr ? __DetectedLocation->calculatePackedSize() + 15 : 1);
      size += sizeof(uint32_t);
      size += sizeof(uint32_t);
      size += sizeof(afrl::cmasi::searchai::HazardType::HazardType);

      return size;
   }

   std::string HazardZoneDetection::toString(int32_t depth) const
   {
      std::string indent(depth*3, ' ');
      std::ostringstream oss;
      oss << std::setprecision(15);
      oss << indent << "Object ( HazardZoneDetection ) {\n";
      indent = std::string((++depth)*3, ' ');
      oss << indent << "DetectedLocation (Location3D)";
      if (__DetectedLocation == nullptr)
         oss << " = nullptr";
      oss << "\n";
      oss << indent << "SensorPayloadID (uint32_t) = " << __SensorPayloadID << "\n";
      oss << indent << "DetectingEnitiyID (uint32_t) = " << __DetectingEnitiyID << "\n";
      oss << indent << "DetectedHazardZoneType (HazardType) = " << __DetectedHazardZoneType << "\n";

      indent = std::string((--depth)*3, ' ');
      oss << indent << "}\n";
      return oss.str();
   }

   std::string HazardZoneDetection::toXML(int32_t depth)
   {
      std::string ws(depth*3, ' ');
      std::ostringstream str;
      str << std::setprecision(15);
      str << ws << "<HazardZoneDetection Series=\"SEARCHAI\">\n";
      if (__DetectedLocation != nullptr)
      {
         str << ws << "   <DetectedLocation>";
         str << "\n" + __DetectedLocation->toXML(depth + 1) + ws + "   ";
         str << "</DetectedLocation>\n";
      }
      str << ws << "   <SensorPayloadID>" << __SensorPayloadID << "</SensorPayloadID>\n";
      str << ws << "   <DetectingEnitiyID>" << __DetectingEnitiyID << "</DetectingEnitiyID>\n";
      str << ws << "   <DetectedHazardZoneType>" << afrl::cmasi::searchai::HazardType::get_string(__DetectedHazardZoneType) << "</DetectedHazardZoneType>\n";
      str << ws << "</HazardZoneDetection>\n";

      return str.str();
   }

   bool HazardZoneDetection::operator==(const HazardZoneDetection & that)
   {
      if( avtas::lmcp::Object::operator!=(that) )
      {
          return false;
      }
      if(__DetectedLocation && that.__DetectedLocation)
      {
         if(__DetectedLocation->getSeriesNameAsLong() != that.__DetectedLocation->getSeriesNameAsLong()) return false;
         if(__DetectedLocation->getSeriesVersion() != that.__DetectedLocation->getSeriesVersion()) return false;
         if(__DetectedLocation->getLmcpType() != that.__DetectedLocation->getLmcpType()) return false;
         if( *(__DetectedLocation) != *(that.__DetectedLocation) ) return false;
      }
      else if(__DetectedLocation != that.__DetectedLocation) return false;
      if(__SensorPayloadID != that.__SensorPayloadID) return false;
      if(__DetectingEnitiyID != that.__DetectingEnitiyID) return false;
      if(__DetectedHazardZoneType != that.__DetectedHazardZoneType) return false;
      return true;

   }

   bool HazardZoneDetection::operator!=(const HazardZoneDetection & that)
   {
      return( !(operator==(that)) );
   }

   HazardZoneDetection& HazardZoneDetection::setDetectedLocation(const afrl::cmasi::Location3D* const val)
   {
      if (__DetectedLocation != nullptr) { delete __DetectedLocation; __DetectedLocation = nullptr; }
      if (val != nullptr) { __DetectedLocation = const_cast< afrl::cmasi::Location3D* > (val); }
      return *this;
   }

   HazardZoneDetection& HazardZoneDetection::setSensorPayloadID(const uint32_t val)
   {
      __SensorPayloadID = val;
      return *this;
   }

   HazardZoneDetection& HazardZoneDetection::setDetectingEnitiyID(const uint32_t val)
   {
      __DetectingEnitiyID = val;
      return *this;
   }

   HazardZoneDetection& HazardZoneDetection::setDetectedHazardZoneType(const afrl::cmasi::searchai::HazardType::HazardType val)
   {
      __DetectedHazardZoneType = val;
      return *this;
   }


} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl

