// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#ifndef _AFRL_CMASI_SEARCHAI_HAZARDTYPE_H_
#define _AFRL_CMASI_SEARCHAI_HAZARDTYPE_H_

#include <string>

namespace afrl {
namespace cmasi {
namespace searchai {



   namespace HazardType {
   enum HazardType {
       /**  Not defined  */
       Undefined = 0,
       /**  fire hazard  */
       Fire = 1,
       /**  smoke hazard  */
       Smoke = 2

   };

   // generates a new HazardType value for the passed string
   inline HazardType get_HazardType(std::string str) {
       if ( str == "Undefined") return Undefined;
       if ( str == "Fire") return Fire;
       if ( str == "Smoke") return Smoke;
        return Undefined;

   }


   // generates a string value for the given enum
   inline std::string get_string(HazardType e) {
       switch(e) {
        case Undefined: return "Undefined";
        case Fire: return "Fire";
        case Smoke: return "Smoke";
        default: return "Undefined";

       }
   }

   }  // namespace HazardType

} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl


#endif // _AFRL_CMASI_SEARCHAI_HAZARDTYPE_H_
