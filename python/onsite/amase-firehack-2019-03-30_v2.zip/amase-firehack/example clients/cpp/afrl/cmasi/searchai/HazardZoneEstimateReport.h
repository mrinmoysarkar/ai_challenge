// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#ifndef _AFRL_CMASI_SEARCHAI_HAZARDZONEESTIMATEREPORT_H_
#define _AFRL_CMASI_SEARCHAI_HAZARDZONEESTIMATEREPORT_H_

#include <cstdint>
#include <memory>
#include <vector>
#include "avtas/lmcp/Factory.h"
#include "SEARCHAIEnum.h"
#include "avtas/lmcp/Object.h"
#include "afrl/cmasi/AbstractGeometry.h"
#include "afrl/cmasi/searchai/HazardType.h"



namespace afrl {
namespace cmasi {
namespace searchai {


   bool isHazardZoneEstimateReport(avtas::lmcp::Object* obj);
   bool isHazardZoneEstimateReport(std::shared_ptr<avtas::lmcp::Object>& obj);
   std::vector< std::string > HazardZoneEstimateReportDescendants();
   
   class HazardZoneEstimateReport : public avtas::lmcp::Object {
   public:
      static const std::string Subscription;
      static const std::string TypeName;
      static const std::string SeriesName;
      static const int64_t SeriesId;
      static const uint16_t SeriesVersion;
      static const uint32_t TypeId;
      
      // Constructor
      HazardZoneEstimateReport(void);

      // Copy Constructor
      HazardZoneEstimateReport(const HazardZoneEstimateReport &that);

      // Assignment Operator
      HazardZoneEstimateReport & operator=(const HazardZoneEstimateReport &that);

      // Destructor
      virtual ~HazardZoneEstimateReport(void);

      // Equals overload
      bool operator==(const HazardZoneEstimateReport & that);
      bool operator!=(const HazardZoneEstimateReport & that);

      // Serializes calling object into a ByteBuffer.
      virtual void pack(avtas::lmcp::ByteBuffer & buf) const;

      // Deserializes ByteBuffer into calling object.
      virtual void unpack(avtas::lmcp::ByteBuffer & buf);

      // Calculates current object size in bytes
      virtual uint32_t calculatePackedSize(void) const;

      // Creates a copy of this object and returns a pointer to it.
      virtual HazardZoneEstimateReport* clone() const;

      // Returns string representation of object
      virtual std::string toString(int32_t depth=0) const;

      // Returns an XML string representation of the object.
      virtual std::string toXML(int32_t depth=0);

      // Returns object type id
      virtual uint32_t getLmcpType(void) const { return TypeId; }
	  
      // Returns object type name string
      virtual std::string getLmcpTypeName(void) const { return TypeName; }
	  
      // Returns object type name string with full namespace prepended, same as subscription name
      virtual std::string getFullLmcpTypeName(void) const { return Subscription; }

      // Returns series name string
      virtual std::string getSeriesName(void) const { return SeriesName; }

      // gets the series name as a long value
      virtual int64_t getSeriesNameAsLong(void) const { return SeriesId; }

      //gets the version number of the series
      virtual uint16_t getSeriesVersion(void) const { return SeriesVersion; }

      // Accessors and Modifiers
      /** A unique ID used by the service providing the estimate. This is used to differentiate perceptions if there are multiple concurrent zones in the scenario. (Units: None)*/
      uint32_t getUniqueTrackingID(void) const { return __UniqueTrackingID; }
      HazardZoneEstimateReport& setUniqueTrackingID(const uint32_t val);

      /** Estimated shape of the zone. Can be null. If null, then the service is reporting that is is not estimating the shape of the zone. (Units: None)*/
      afrl::cmasi::AbstractGeometry* const getEstimatedZoneShape(void) { return __EstimatedZoneShape; }
      HazardZoneEstimateReport& setEstimatedZoneShape(const afrl::cmasi::AbstractGeometry* const val);

      /** Estimated rate of change in the average radius of the zone. Can be negative. (Units: m/s)*/
      float getEstimatedGrowthRate(void) const { return __EstimatedGrowthRate; }
      HazardZoneEstimateReport& setEstimatedGrowthRate(const float val);

      /** Type of perceived zone being reported (Units: None)*/
      afrl::cmasi::searchai::HazardType::HazardType getPerceivedZoneType(void) const { return __PerceivedZoneType; }
      HazardZoneEstimateReport& setPerceivedZoneType(const afrl::cmasi::searchai::HazardType::HazardType val);

      /** Estimated true compass direction of movement of the hazard zone. (Units: Degree)*/
      float getEstimatedZoneDirection(void) const { return __EstimatedZoneDirection; }
      HazardZoneEstimateReport& setEstimatedZoneDirection(const float val);

      /** Estimated speed of the hazard zone. This is the speed of the centerpoint of the shape. (Units: m/s)*/
      float getEstimatedZoneSpeed(void) const { return __EstimatedZoneSpeed; }
      HazardZoneEstimateReport& setEstimatedZoneSpeed(const float val);



   protected:
      /** A unique ID used by the service providing the estimate. This is used to differentiate perceptions if there are multiple concurrent zones in the scenario. */
      uint32_t __UniqueTrackingID;
      /** Estimated shape of the zone. Can be null. If null, then the service is reporting that is is not estimating the shape of the zone. */
      afrl::cmasi::AbstractGeometry* __EstimatedZoneShape;
      /** Estimated rate of change in the average radius of the zone. Can be negative. */
      float __EstimatedGrowthRate;
      /** Type of perceived zone being reported */
      afrl::cmasi::searchai::HazardType::HazardType __PerceivedZoneType;
      /** Estimated true compass direction of movement of the hazard zone. */
      float __EstimatedZoneDirection;
      /** Estimated speed of the hazard zone. This is the speed of the centerpoint of the shape. */
      float __EstimatedZoneSpeed;

   };

} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl


#endif // _AFRL_CMASI_SEARCHAI_HAZARDZONEESTIMATEREPORT_H_
