// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#include <cassert>
#include <sstream>
#include <iomanip>
#include "afrl/cmasi/searchai/HazardSensorState.h"


namespace afrl {
namespace cmasi {
namespace searchai {


   // Subscription string is namespace separated by '.' followed by type name
   const std::string HazardSensorState::Subscription = "afrl.cmasi.searchai.HazardSensorState";
   const std::string HazardSensorState::TypeName = "HazardSensorState";
   const std::string HazardSensorState::SeriesName = "SEARCHAI";
   const int64_t HazardSensorState::SeriesId = 6000273900112986441LL;
   const uint16_t HazardSensorState::SeriesVersion = 5;
   const uint32_t HazardSensorState::TypeId = 7;
   
   bool isHazardSensorState(avtas::lmcp::Object* obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 7) return false;
      return true;
   }
   
   bool isHazardSensorState(std::shared_ptr<avtas::lmcp::Object>& obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 7) return false;
      return true;
   }
   
   std::vector< std::string > HazardSensorStateDescendants()
   {
       std::vector< std::string > descendants;
       

       return descendants;
   }
   
   HazardSensorState::HazardSensorState(void) : afrl::cmasi::CameraState()
   {

   }
     
   HazardSensorState::HazardSensorState(const HazardSensorState &that) : afrl::cmasi::CameraState(that)
   {

   }
   
   HazardSensorState & HazardSensorState::operator=(const HazardSensorState &that)
   {
      if (this != &that)
      {
         afrl::cmasi::CameraState::operator=(that);


      }
      return *this;
   }

   HazardSensorState* HazardSensorState::clone() const
   {
        return new HazardSensorState(*this);
   }
   
   HazardSensorState::~HazardSensorState(void)
   {

   }
  
   void HazardSensorState::pack(avtas::lmcp::ByteBuffer & buf) const
   {
      // Call parent's pack method
      afrl::cmasi::CameraState::pack(buf);
      // Copy the class into the buffer

   }
   
   void HazardSensorState::unpack(avtas::lmcp::ByteBuffer & buf)
   {
      // Call parent's unpack method
      afrl::cmasi::CameraState::unpack(buf);
      // Copy the buffer into the class

   }

   uint32_t HazardSensorState::calculatePackedSize(void) const
   {
      uint32_t size = 0;
      size += afrl::cmasi::CameraState::calculatePackedSize();

      return size;
   }

   std::string HazardSensorState::toString(int32_t depth) const
   {
      std::string indent(depth*3, ' ');
      std::ostringstream oss;
      oss << std::setprecision(15);
      oss << indent << "Object ( HazardSensorState ) {\n";
      indent = std::string((++depth)*3, ' ');
      oss << indent << "PayloadID (int64_t) = " << __PayloadID << "\n";
      oss << indent << "Parameters (KeyValuePair [ " << __Parameters.size() << ", var ])\n";

      oss << indent << "PointingMode (GimbalPointingMode) = " << __PointingMode << "\n";
      oss << indent << "Azimuth (float) = " << __Azimuth << "\n";
      oss << indent << "Elevation (float) = " << __Elevation << "\n";
      oss << indent << "Rotation (float) = " << __Rotation << "\n";

      oss << indent << "HorizontalFieldOfView (float) = " << __HorizontalFieldOfView << "\n";
      oss << indent << "VerticalFieldOfView (float) = " << __VerticalFieldOfView << "\n";
      oss << indent << "Footprint (Location3D [ " << __Footprint.size() << ", var ])\n";
      oss << indent << "Centerpoint (Location3D)";
      if (__Centerpoint == nullptr)
         oss << " = nullptr";
      oss << "\n";


      indent = std::string((--depth)*3, ' ');
      oss << indent << "}\n";
      return oss.str();
   }

   std::string HazardSensorState::toXML(int32_t depth)
   {
      std::string ws(depth*3, ' ');
      std::ostringstream str;
      str << std::setprecision(15);
      str << ws << "<HazardSensorState Series=\"SEARCHAI\">\n";
      str << ws << "   <HorizontalFieldOfView>" << __HorizontalFieldOfView << "</HorizontalFieldOfView>\n";
      str << ws << "   <VerticalFieldOfView>" << __VerticalFieldOfView << "</VerticalFieldOfView>\n";
      str << ws << "   <Footprint>\n";
      for (size_t i=0; i<__Footprint.size(); i++)
      {
         str << (__Footprint[i] == nullptr ? ( ws + "   <null/>\n") : (__Footprint[i]->toXML(depth + 1))) ;
      }
      str << ws << "   </Footprint>\n";
      if (__Centerpoint != nullptr)
      {
         str << ws << "   <Centerpoint>";
         str << "\n" + __Centerpoint->toXML(depth + 1) + ws + "   ";
         str << "</Centerpoint>\n";
      }
      str << ws << "   <PointingMode>" << afrl::cmasi::GimbalPointingMode::get_string(__PointingMode) << "</PointingMode>\n";
      str << ws << "   <Azimuth>" << __Azimuth << "</Azimuth>\n";
      str << ws << "   <Elevation>" << __Elevation << "</Elevation>\n";
      str << ws << "   <Rotation>" << __Rotation << "</Rotation>\n";
      str << ws << "   <PayloadID>" << __PayloadID << "</PayloadID>\n";
      str << ws << "   <Parameters>\n";
      for (size_t i=0; i<__Parameters.size(); i++)
      {
         str << (__Parameters[i] == nullptr ? ( ws + "   <null/>\n") : (__Parameters[i]->toXML(depth + 1))) ;
      }
      str << ws << "   </Parameters>\n";
      str << ws << "</HazardSensorState>\n";

      return str.str();
   }

   bool HazardSensorState::operator==(const HazardSensorState & that)
   {
      if( afrl::cmasi::CameraState::operator!=(that) )
      {
          return false;
      }
      return true;

   }

   bool HazardSensorState::operator!=(const HazardSensorState & that)
   {
      return( !(operator==(that)) );
   }


} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl

