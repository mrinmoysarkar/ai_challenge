// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#include "afrl/cmasi/searchai/SEARCHAIXMLReader.h"
#include "avtas/lmcp/XMLParser.h"
#include <vector>
#include <string>
#include "avtas/lmcp/LmcpXMLReader.h"

#include "afrl/cmasi/searchai/HazardZone.h"
#include "afrl/cmasi/searchai/HazardZoneDetection.h"
#include "afrl/cmasi/searchai/HazardZoneEstimateReport.h"
#include "afrl/cmasi/searchai/RecoveryPoint.h"
#include "afrl/cmasi/searchai/HazardZoneChangeCommand.h"
#include "afrl/cmasi/searchai/HazardSensorConfiguration.h"
#include "afrl/cmasi/searchai/HazardSensorState.h"
#include "afrl/cmasi/searchai/HazardType.h"
#include "afrl/cmasi/searchai/SEARCHAIEnum.h"


using namespace avtas::lmcp;
using namespace avtas::lmcp::xml;


namespace afrl {
namespace cmasi {
namespace searchai {


    avtas::lmcp::Object* SEARCHAIXMLReader :: visitType(avtas::lmcp::Node* el){

        if (el == NULL) return NULL;
        
        std::string type = el->getTagName();
            
        if (type == "HazardZone"){
           HazardZone* o = new HazardZone();
           for (uint32_t i=0; i<el->getChildCount(); i++)
           {
              std::string name = el->getChild(i)->getTagName();
              if(name == "ZoneType")
              {
                 Node* tmp = el->getChild(i);
                 o->setZoneType( afrl::cmasi::searchai::HazardType::get_HazardType( get_string( tmp )));
                 continue;
              }
              if(name == "ZoneID")
              {
                 Node* tmp = el->getChild(i);
                 o->setZoneID( get_int64( tmp ));
                 continue;
              }
              if(name == "MinAltitude")
              {
                 Node* tmp = el->getChild(i);
                 o->setMinAltitude( get_real32( tmp ));
                 continue;
              }
              if(name == "MinAltitudeType")
              {
                 Node* tmp = el->getChild(i);
                 o->setMinAltitudeType( afrl::cmasi::AltitudeType::get_AltitudeType( get_string( tmp )));
                 continue;
              }
              if(name == "MaxAltitude")
              {
                 Node* tmp = el->getChild(i);
                 o->setMaxAltitude( get_real32( tmp ));
                 continue;
              }
              if(name == "MaxAltitudeType")
              {
                 Node* tmp = el->getChild(i);
                 o->setMaxAltitudeType( afrl::cmasi::AltitudeType::get_AltitudeType( get_string( tmp )));
                 continue;
              }
              if(name == "AffectedAircraft")
              {
                 Node* tmp = el->getChild(i);
                 for (uint32_t j=0; j<tmp->getChildCount(); j++)
                 {
                    o->getAffectedAircraft().push_back( get_int64( tmp->getChild(j)));
                 }
                 continue;
              }
              if(name == "StartTime")
              {
                 Node* tmp = el->getChild(i);
                 o->setStartTime( get_int64( tmp ));
                 continue;
              }
              if(name == "EndTime")
              {
                 Node* tmp = el->getChild(i);
                 o->setEndTime( get_int64( tmp ));
                 continue;
              }
              if(name == "Padding")
              {
                 Node* tmp = el->getChild(i);
                 o->setPadding( get_real32( tmp ));
                 continue;
              }
              if(name == "Label")
              {
                 Node* tmp = el->getChild(i);
                 o->setLabel( get_string( tmp ));
                 continue;
              }
              if(name == "Boundary")
              {
                 Node* tmp = el->getChild(i);
                 Object* oo = readXML( tmp->getChild(0) );
                 o->setBoundary((afrl::cmasi::AbstractGeometry*) oo );
                 continue;
              }
           }
           return o;
        }
        if (type == "HazardZoneDetection"){
           HazardZoneDetection* o = new HazardZoneDetection();
           for (uint32_t i=0; i<el->getChildCount(); i++)
           {
              std::string name = el->getChild(i)->getTagName();
              if(name == "DetectedLocation")
              {
                 Node* tmp = el->getChild(i);
                 Object* oo = readXML( tmp->getChild(0) );
                 o->setDetectedLocation((afrl::cmasi::Location3D*) oo );
                 continue;
              }
              if(name == "SensorPayloadID")
              {
                 Node* tmp = el->getChild(i);
                 o->setSensorPayloadID( get_uint32( tmp ));
                 continue;
              }
              if(name == "DetectingEnitiyID")
              {
                 Node* tmp = el->getChild(i);
                 o->setDetectingEnitiyID( get_uint32( tmp ));
                 continue;
              }
              if(name == "DetectedHazardZoneType")
              {
                 Node* tmp = el->getChild(i);
                 o->setDetectedHazardZoneType( afrl::cmasi::searchai::HazardType::get_HazardType( get_string( tmp )));
                 continue;
              }
           }
           return o;
        }
        if (type == "HazardZoneEstimateReport"){
           HazardZoneEstimateReport* o = new HazardZoneEstimateReport();
           for (uint32_t i=0; i<el->getChildCount(); i++)
           {
              std::string name = el->getChild(i)->getTagName();
              if(name == "UniqueTrackingID")
              {
                 Node* tmp = el->getChild(i);
                 o->setUniqueTrackingID( get_uint32( tmp ));
                 continue;
              }
              if(name == "EstimatedZoneShape")
              {
                 Node* tmp = el->getChild(i);
                 Object* oo = readXML( tmp->getChild(0) );
                 o->setEstimatedZoneShape((afrl::cmasi::AbstractGeometry*) oo );
                 continue;
              }
              if(name == "EstimatedGrowthRate")
              {
                 Node* tmp = el->getChild(i);
                 o->setEstimatedGrowthRate( get_real32( tmp ));
                 continue;
              }
              if(name == "PerceivedZoneType")
              {
                 Node* tmp = el->getChild(i);
                 o->setPerceivedZoneType( afrl::cmasi::searchai::HazardType::get_HazardType( get_string( tmp )));
                 continue;
              }
              if(name == "EstimatedZoneDirection")
              {
                 Node* tmp = el->getChild(i);
                 o->setEstimatedZoneDirection( get_real32( tmp ));
                 continue;
              }
              if(name == "EstimatedZoneSpeed")
              {
                 Node* tmp = el->getChild(i);
                 o->setEstimatedZoneSpeed( get_real32( tmp ));
                 continue;
              }
           }
           return o;
        }
        if (type == "RecoveryPoint"){
           RecoveryPoint* o = new RecoveryPoint();
           for (uint32_t i=0; i<el->getChildCount(); i++)
           {
              std::string name = el->getChild(i)->getTagName();
              if(name == "LocationName")
              {
                 Node* tmp = el->getChild(i);
                 o->setLocationName( get_string( tmp ));
                 continue;
              }
              if(name == "ZoneID")
              {
                 Node* tmp = el->getChild(i);
                 o->setZoneID( get_int64( tmp ));
                 continue;
              }
              if(name == "MinAltitude")
              {
                 Node* tmp = el->getChild(i);
                 o->setMinAltitude( get_real32( tmp ));
                 continue;
              }
              if(name == "MinAltitudeType")
              {
                 Node* tmp = el->getChild(i);
                 o->setMinAltitudeType( afrl::cmasi::AltitudeType::get_AltitudeType( get_string( tmp )));
                 continue;
              }
              if(name == "MaxAltitude")
              {
                 Node* tmp = el->getChild(i);
                 o->setMaxAltitude( get_real32( tmp ));
                 continue;
              }
              if(name == "MaxAltitudeType")
              {
                 Node* tmp = el->getChild(i);
                 o->setMaxAltitudeType( afrl::cmasi::AltitudeType::get_AltitudeType( get_string( tmp )));
                 continue;
              }
              if(name == "AffectedAircraft")
              {
                 Node* tmp = el->getChild(i);
                 for (uint32_t j=0; j<tmp->getChildCount(); j++)
                 {
                    o->getAffectedAircraft().push_back( get_int64( tmp->getChild(j)));
                 }
                 continue;
              }
              if(name == "StartTime")
              {
                 Node* tmp = el->getChild(i);
                 o->setStartTime( get_int64( tmp ));
                 continue;
              }
              if(name == "EndTime")
              {
                 Node* tmp = el->getChild(i);
                 o->setEndTime( get_int64( tmp ));
                 continue;
              }
              if(name == "Padding")
              {
                 Node* tmp = el->getChild(i);
                 o->setPadding( get_real32( tmp ));
                 continue;
              }
              if(name == "Label")
              {
                 Node* tmp = el->getChild(i);
                 o->setLabel( get_string( tmp ));
                 continue;
              }
              if(name == "Boundary")
              {
                 Node* tmp = el->getChild(i);
                 Object* oo = readXML( tmp->getChild(0) );
                 o->setBoundary((afrl::cmasi::AbstractGeometry*) oo );
                 continue;
              }
           }
           return o;
        }
        if (type == "HazardZoneChangeCommand"){
           HazardZoneChangeCommand* o = new HazardZoneChangeCommand();
           for (uint32_t i=0; i<el->getChildCount(); i++)
           {
              std::string name = el->getChild(i)->getTagName();
              if(name == "ZoneID")
              {
                 Node* tmp = el->getChild(i);
                 o->setZoneID( get_uint32( tmp ));
                 continue;
              }
              if(name == "GrowthRate")
              {
                 Node* tmp = el->getChild(i);
                 o->setGrowthRate( get_real32( tmp ));
                 continue;
              }
              if(name == "TranslationRate")
              {
                 Node* tmp = el->getChild(i);
                 o->setTranslationRate( get_real32( tmp ));
                 continue;
              }
              if(name == "TranslationDirection")
              {
                 Node* tmp = el->getChild(i);
                 o->setTranslationDirection( get_real32( tmp ));
                 continue;
              }
           }
           return o;
        }
        if (type == "HazardSensorConfiguration"){
           HazardSensorConfiguration* o = new HazardSensorConfiguration();
           for (uint32_t i=0; i<el->getChildCount(); i++)
           {
              std::string name = el->getChild(i)->getTagName();
              if(name == "MaxRange")
              {
                 Node* tmp = el->getChild(i);
                 o->setMaxRange( get_real32( tmp ));
                 continue;
              }
              if(name == "HorizontalFOV")
              {
                 Node* tmp = el->getChild(i);
                 o->setHorizontalFOV( get_real32( tmp ));
                 continue;
              }
              if(name == "VerticalFOV")
              {
                 Node* tmp = el->getChild(i);
                 o->setVerticalFOV( get_real32( tmp ));
                 continue;
              }
              if(name == "DetectableHazardTypes")
              {
                 Node* tmp = el->getChild(i);
                 for (uint32_t j=0; j<tmp->getChildCount(); j++)
                 {
                    o->getDetectableHazardTypes().push_back( afrl::cmasi::searchai::HazardType::get_HazardType(get_string( tmp->getChild(j))));
                 }
                 continue;
              }
              if(name == "PayloadID")
              {
                 Node* tmp = el->getChild(i);
                 o->setPayloadID( get_int64( tmp ));
                 continue;
              }
              if(name == "PayloadKind")
              {
                 Node* tmp = el->getChild(i);
                 o->setPayloadKind( get_string( tmp ));
                 continue;
              }
              if(name == "Parameters")
              {
                 Node* tmp = el->getChild(i);
                 for (uint32_t j=0; j<tmp->getChildCount(); j++)
                 {
                    Object* oo = readXML( tmp->getChild(j));
                    o->getParameters().push_back( (afrl::cmasi::KeyValuePair*) oo);
                 }
                 continue;
              }
           }
           return o;
        }
        if (type == "HazardSensorState"){
           HazardSensorState* o = new HazardSensorState();
           for (uint32_t i=0; i<el->getChildCount(); i++)
           {
              std::string name = el->getChild(i)->getTagName();
              if(name == "HorizontalFieldOfView")
              {
                 Node* tmp = el->getChild(i);
                 o->setHorizontalFieldOfView( get_real32( tmp ));
                 continue;
              }
              if(name == "VerticalFieldOfView")
              {
                 Node* tmp = el->getChild(i);
                 o->setVerticalFieldOfView( get_real32( tmp ));
                 continue;
              }
              if(name == "Footprint")
              {
                 Node* tmp = el->getChild(i);
                 for (uint32_t j=0; j<tmp->getChildCount(); j++)
                 {
                    Object* oo = readXML( tmp->getChild(j));
                    o->getFootprint().push_back( (afrl::cmasi::Location3D*) oo);
                 }
                 continue;
              }
              if(name == "Centerpoint")
              {
                 Node* tmp = el->getChild(i);
                 Object* oo = readXML( tmp->getChild(0) );
                 o->setCenterpoint((afrl::cmasi::Location3D*) oo );
                 continue;
              }
              if(name == "PointingMode")
              {
                 Node* tmp = el->getChild(i);
                 o->setPointingMode( afrl::cmasi::GimbalPointingMode::get_GimbalPointingMode( get_string( tmp )));
                 continue;
              }
              if(name == "Azimuth")
              {
                 Node* tmp = el->getChild(i);
                 o->setAzimuth( get_real32( tmp ));
                 continue;
              }
              if(name == "Elevation")
              {
                 Node* tmp = el->getChild(i);
                 o->setElevation( get_real32( tmp ));
                 continue;
              }
              if(name == "Rotation")
              {
                 Node* tmp = el->getChild(i);
                 o->setRotation( get_real32( tmp ));
                 continue;
              }
              if(name == "PayloadID")
              {
                 Node* tmp = el->getChild(i);
                 o->setPayloadID( get_int64( tmp ));
                 continue;
              }
              if(name == "Parameters")
              {
                 Node* tmp = el->getChild(i);
                 for (uint32_t j=0; j<tmp->getChildCount(); j++)
                 {
                    Object* oo = readXML( tmp->getChild(j));
                    o->getParameters().push_back( (afrl::cmasi::KeyValuePair*) oo);
                 }
                 continue;
              }
           }
           return o;
        }


         return NULL;
        
    }

} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl

