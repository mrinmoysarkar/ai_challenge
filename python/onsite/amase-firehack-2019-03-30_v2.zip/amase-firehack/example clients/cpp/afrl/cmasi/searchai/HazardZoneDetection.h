// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#ifndef _AFRL_CMASI_SEARCHAI_HAZARDZONEDETECTION_H_
#define _AFRL_CMASI_SEARCHAI_HAZARDZONEDETECTION_H_

#include <cstdint>
#include <memory>
#include <vector>
#include "avtas/lmcp/Factory.h"
#include "SEARCHAIEnum.h"
#include "avtas/lmcp/Object.h"
#include "afrl/cmasi/Location3D.h"
#include "afrl/cmasi/searchai/HazardType.h"



namespace afrl {
namespace cmasi {
namespace searchai {


   bool isHazardZoneDetection(avtas::lmcp::Object* obj);
   bool isHazardZoneDetection(std::shared_ptr<avtas::lmcp::Object>& obj);
   std::vector< std::string > HazardZoneDetectionDescendants();
   
   class HazardZoneDetection : public avtas::lmcp::Object {
   public:
      static const std::string Subscription;
      static const std::string TypeName;
      static const std::string SeriesName;
      static const int64_t SeriesId;
      static const uint16_t SeriesVersion;
      static const uint32_t TypeId;
      
      // Constructor
      HazardZoneDetection(void);

      // Copy Constructor
      HazardZoneDetection(const HazardZoneDetection &that);

      // Assignment Operator
      HazardZoneDetection & operator=(const HazardZoneDetection &that);

      // Destructor
      virtual ~HazardZoneDetection(void);

      // Equals overload
      bool operator==(const HazardZoneDetection & that);
      bool operator!=(const HazardZoneDetection & that);

      // Serializes calling object into a ByteBuffer.
      virtual void pack(avtas::lmcp::ByteBuffer & buf) const;

      // Deserializes ByteBuffer into calling object.
      virtual void unpack(avtas::lmcp::ByteBuffer & buf);

      // Calculates current object size in bytes
      virtual uint32_t calculatePackedSize(void) const;

      // Creates a copy of this object and returns a pointer to it.
      virtual HazardZoneDetection* clone() const;

      // Returns string representation of object
      virtual std::string toString(int32_t depth=0) const;

      // Returns an XML string representation of the object.
      virtual std::string toXML(int32_t depth=0);

      // Returns object type id
      virtual uint32_t getLmcpType(void) const { return TypeId; }
	  
      // Returns object type name string
      virtual std::string getLmcpTypeName(void) const { return TypeName; }
	  
      // Returns object type name string with full namespace prepended, same as subscription name
      virtual std::string getFullLmcpTypeName(void) const { return Subscription; }

      // Returns series name string
      virtual std::string getSeriesName(void) const { return SeriesName; }

      // gets the series name as a long value
      virtual int64_t getSeriesNameAsLong(void) const { return SeriesId; }

      //gets the version number of the series
      virtual uint16_t getSeriesVersion(void) const { return SeriesVersion; }

      // Accessors and Modifiers
      /** Approximate location of detected Zone. Zero altitude denotes ground level (Units: None)*/
      afrl::cmasi::Location3D* const getDetectedLocation(void) { return __DetectedLocation; }
      HazardZoneDetection& setDetectedLocation(const afrl::cmasi::Location3D* const val);

      /** Sensor payload ID of sensor performing the detection (Units: None)*/
      uint32_t getSensorPayloadID(void) const { return __SensorPayloadID; }
      HazardZoneDetection& setSensorPayloadID(const uint32_t val);

      /** ID of the entity (aircraft) that is making the detection (Units: None)*/
      uint32_t getDetectingEnitiyID(void) const { return __DetectingEnitiyID; }
      HazardZoneDetection& setDetectingEnitiyID(const uint32_t val);

      /** Type of the hazard zone detected (Units: None)*/
      afrl::cmasi::searchai::HazardType::HazardType getDetectedHazardZoneType(void) const { return __DetectedHazardZoneType; }
      HazardZoneDetection& setDetectedHazardZoneType(const afrl::cmasi::searchai::HazardType::HazardType val);



   protected:
      /** Approximate location of detected Zone. Zero altitude denotes ground level */
      afrl::cmasi::Location3D* __DetectedLocation;
      /** Sensor payload ID of sensor performing the detection */
      uint32_t __SensorPayloadID;
      /** ID of the entity (aircraft) that is making the detection */
      uint32_t __DetectingEnitiyID;
      /** Type of the hazard zone detected */
      afrl::cmasi::searchai::HazardType::HazardType __DetectedHazardZoneType;

   };

} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl


#endif // _AFRL_CMASI_SEARCHAI_HAZARDZONEDETECTION_H_
