// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#ifndef _AFRL_CMASI_SEARCHAI_SEARCHAIENUM_H_
#define _AFRL_CMASI_SEARCHAI_SEARCHAIENUM_H_


namespace afrl {
namespace cmasi {
namespace searchai {


   namespace SEARCHAIEnum {

      enum LmcpType {
         HAZARDZONE = 1,
         HAZARDZONEDETECTION = 2,
         HAZARDZONEESTIMATEREPORT = 3,
         RECOVERYPOINT = 4,
         HAZARDZONECHANGECOMMAND = 5,
         HAZARDSENSORCONFIGURATION = 6,
         HAZARDSENSORSTATE = 7
      };

   }

} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl


#endif //_AFRL_CMASI_SEARCHAI_SEARCHAIENUM_H_
