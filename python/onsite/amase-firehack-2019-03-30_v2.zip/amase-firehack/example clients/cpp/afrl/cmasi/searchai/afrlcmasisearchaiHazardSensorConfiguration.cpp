// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#include <cassert>
#include <sstream>
#include <iomanip>
#include "afrl/cmasi/searchai/HazardSensorConfiguration.h"


namespace afrl {
namespace cmasi {
namespace searchai {


   // Subscription string is namespace separated by '.' followed by type name
   const std::string HazardSensorConfiguration::Subscription = "afrl.cmasi.searchai.HazardSensorConfiguration";
   const std::string HazardSensorConfiguration::TypeName = "HazardSensorConfiguration";
   const std::string HazardSensorConfiguration::SeriesName = "SEARCHAI";
   const int64_t HazardSensorConfiguration::SeriesId = 6000273900112986441LL;
   const uint16_t HazardSensorConfiguration::SeriesVersion = 5;
   const uint32_t HazardSensorConfiguration::TypeId = 6;
   
   bool isHazardSensorConfiguration(avtas::lmcp::Object* obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 6) return false;
      return true;
   }
   
   bool isHazardSensorConfiguration(std::shared_ptr<avtas::lmcp::Object>& obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 6) return false;
      return true;
   }
   
   std::vector< std::string > HazardSensorConfigurationDescendants()
   {
       std::vector< std::string > descendants;
       

       return descendants;
   }
   
   HazardSensorConfiguration::HazardSensorConfiguration(void) : afrl::cmasi::PayloadConfiguration()
   {
      __MaxRange = 0.f;
      __HorizontalFOV = 0.f;
      __VerticalFOV = 0.f;

   }
     
   HazardSensorConfiguration::HazardSensorConfiguration(const HazardSensorConfiguration &that) : afrl::cmasi::PayloadConfiguration(that)
   {
        __MaxRange = that.__MaxRange;
        __HorizontalFOV = that.__HorizontalFOV;
        __VerticalFOV = that.__VerticalFOV;
        __DetectableHazardTypes.clear();
        for (size_t i=0; i< that.__DetectableHazardTypes.size(); i++)
        {
           __DetectableHazardTypes.push_back( that.__DetectableHazardTypes[i]);
        }

   }
   
   HazardSensorConfiguration & HazardSensorConfiguration::operator=(const HazardSensorConfiguration &that)
   {
      if (this != &that)
      {
         afrl::cmasi::PayloadConfiguration::operator=(that);

         __MaxRange = that.__MaxRange;
         __HorizontalFOV = that.__HorizontalFOV;
         __VerticalFOV = that.__VerticalFOV;
         __DetectableHazardTypes.clear();
         for (size_t i=0; i< that.__DetectableHazardTypes.size(); i++)
         {
            __DetectableHazardTypes.push_back( that.__DetectableHazardTypes[i]);
         }

      }
      return *this;
   }

   HazardSensorConfiguration* HazardSensorConfiguration::clone() const
   {
        return new HazardSensorConfiguration(*this);
   }
   
   HazardSensorConfiguration::~HazardSensorConfiguration(void)
   {

   }
  
   void HazardSensorConfiguration::pack(avtas::lmcp::ByteBuffer & buf) const
   {
      // Call parent's pack method
      afrl::cmasi::PayloadConfiguration::pack(buf);
      // Copy the class into the buffer
      buf.putFloat(__MaxRange);
      buf.putFloat(__HorizontalFOV);
      buf.putFloat(__VerticalFOV);
      buf.putUShort( static_cast<uint16_t>(__DetectableHazardTypes.size()));
      for (size_t i=0; i<__DetectableHazardTypes.size(); i++)
      {
         buf.putInt( (int32_t) __DetectableHazardTypes[i]);
      }

   }
   
   void HazardSensorConfiguration::unpack(avtas::lmcp::ByteBuffer & buf)
   {
      // Call parent's unpack method
      afrl::cmasi::PayloadConfiguration::unpack(buf);
      // Copy the buffer into the class
      __MaxRange = buf.getFloat();
      __HorizontalFOV = buf.getFloat();
      __VerticalFOV = buf.getFloat();
      __DetectableHazardTypes.clear();
      uint16_t __DetectableHazardTypes_length = buf.getUShort();
      for (uint32_t i=0; i< __DetectableHazardTypes_length; i++)
      {
         __DetectableHazardTypes.push_back( (afrl::cmasi::searchai::HazardType::HazardType) buf.getInt() );
      }

   }

   uint32_t HazardSensorConfiguration::calculatePackedSize(void) const
   {
      uint32_t size = 0;
      size += afrl::cmasi::PayloadConfiguration::calculatePackedSize();
      size += sizeof(float);
      size += sizeof(float);
      size += sizeof(float);
      size += 2 + sizeof(afrl::cmasi::searchai::HazardType::HazardType) * __DetectableHazardTypes.size();

      return size;
   }

   std::string HazardSensorConfiguration::toString(int32_t depth) const
   {
      std::string indent(depth*3, ' ');
      std::ostringstream oss;
      oss << std::setprecision(15);
      oss << indent << "Object ( HazardSensorConfiguration ) {\n";
      indent = std::string((++depth)*3, ' ');
      oss << indent << "PayloadID (int64_t) = " << __PayloadID << "\n";
      oss << indent << "PayloadKind (std::string) = " << __PayloadKind << "\n";
      oss << indent << "Parameters (KeyValuePair [ " << __Parameters.size() << ", var ])\n";

      oss << indent << "MaxRange (float) = " << __MaxRange << "\n";
      oss << indent << "HorizontalFOV (float) = " << __HorizontalFOV << "\n";
      oss << indent << "VerticalFOV (float) = " << __VerticalFOV << "\n";
      oss << indent << "DetectableHazardTypes (HazardType [ " << __DetectableHazardTypes.size() << ", var ])\n";

      indent = std::string((--depth)*3, ' ');
      oss << indent << "}\n";
      return oss.str();
   }

   std::string HazardSensorConfiguration::toXML(int32_t depth)
   {
      std::string ws(depth*3, ' ');
      std::ostringstream str;
      str << std::setprecision(15);
      str << ws << "<HazardSensorConfiguration Series=\"SEARCHAI\">\n";
      str << ws << "   <MaxRange>" << __MaxRange << "</MaxRange>\n";
      str << ws << "   <HorizontalFOV>" << __HorizontalFOV << "</HorizontalFOV>\n";
      str << ws << "   <VerticalFOV>" << __VerticalFOV << "</VerticalFOV>\n";
      str << ws << "   <DetectableHazardTypes>\n";
      for (size_t i=0; i<__DetectableHazardTypes.size(); i++)
      {
         str << ws << "   <HazardType>" << afrl::cmasi::searchai::HazardType::get_string(__DetectableHazardTypes[i]) << "</HazardType>\n";
      }
      str << ws << "   </DetectableHazardTypes>\n";
      str << ws << "   <PayloadID>" << __PayloadID << "</PayloadID>\n";
      str << ws << "   <PayloadKind>" << __PayloadKind << "</PayloadKind>\n";
      str << ws << "   <Parameters>\n";
      for (size_t i=0; i<__Parameters.size(); i++)
      {
         str << (__Parameters[i] == nullptr ? ( ws + "   <null/>\n") : (__Parameters[i]->toXML(depth + 1))) ;
      }
      str << ws << "   </Parameters>\n";
      str << ws << "</HazardSensorConfiguration>\n";

      return str.str();
   }

   bool HazardSensorConfiguration::operator==(const HazardSensorConfiguration & that)
   {
      if( afrl::cmasi::PayloadConfiguration::operator!=(that) )
      {
          return false;
      }
      if(__MaxRange != that.__MaxRange) return false;
      if(__HorizontalFOV != that.__HorizontalFOV) return false;
      if(__VerticalFOV != that.__VerticalFOV) return false;
      if(__DetectableHazardTypes.size() != that.__DetectableHazardTypes.size()) return false;
      for (size_t i=0; i<__DetectableHazardTypes.size(); i++)
      {
         if(__DetectableHazardTypes[i] != that.__DetectableHazardTypes[i]) return false;
      }
      return true;

   }

   bool HazardSensorConfiguration::operator!=(const HazardSensorConfiguration & that)
   {
      return( !(operator==(that)) );
   }

   HazardSensorConfiguration& HazardSensorConfiguration::setMaxRange(const float val)
   {
      __MaxRange = val;
      return *this;
   }

   HazardSensorConfiguration& HazardSensorConfiguration::setHorizontalFOV(const float val)
   {
      __HorizontalFOV = val;
      return *this;
   }

   HazardSensorConfiguration& HazardSensorConfiguration::setVerticalFOV(const float val)
   {
      __VerticalFOV = val;
      return *this;
   }



} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl

