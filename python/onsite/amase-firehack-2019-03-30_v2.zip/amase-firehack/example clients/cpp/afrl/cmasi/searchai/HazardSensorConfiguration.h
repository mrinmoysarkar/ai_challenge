// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#ifndef _AFRL_CMASI_SEARCHAI_HAZARDSENSORCONFIGURATION_H_
#define _AFRL_CMASI_SEARCHAI_HAZARDSENSORCONFIGURATION_H_

#include <cstdint>
#include <memory>
#include <vector>
#include "avtas/lmcp/Factory.h"
#include "SEARCHAIEnum.h"
#include "afrl/cmasi/PayloadConfiguration.h"
#include "afrl/cmasi/searchai/HazardType.h"

#include <vector>


namespace afrl {
namespace cmasi {
namespace searchai {


   bool isHazardSensorConfiguration(avtas::lmcp::Object* obj);
   bool isHazardSensorConfiguration(std::shared_ptr<avtas::lmcp::Object>& obj);
   std::vector< std::string > HazardSensorConfigurationDescendants();
   
   class HazardSensorConfiguration : public afrl::cmasi::PayloadConfiguration {
   public:
      static const std::string Subscription;
      static const std::string TypeName;
      static const std::string SeriesName;
      static const int64_t SeriesId;
      static const uint16_t SeriesVersion;
      static const uint32_t TypeId;
      
      // Constructor
      HazardSensorConfiguration(void);

      // Copy Constructor
      HazardSensorConfiguration(const HazardSensorConfiguration &that);

      // Assignment Operator
      HazardSensorConfiguration & operator=(const HazardSensorConfiguration &that);

      // Destructor
      virtual ~HazardSensorConfiguration(void);

      // Equals overload
      bool operator==(const HazardSensorConfiguration & that);
      bool operator!=(const HazardSensorConfiguration & that);

      // Serializes calling object into a ByteBuffer.
      virtual void pack(avtas::lmcp::ByteBuffer & buf) const;

      // Deserializes ByteBuffer into calling object.
      virtual void unpack(avtas::lmcp::ByteBuffer & buf);

      // Calculates current object size in bytes
      virtual uint32_t calculatePackedSize(void) const;

      // Creates a copy of this object and returns a pointer to it.
      virtual HazardSensorConfiguration* clone() const;

      // Returns string representation of object
      virtual std::string toString(int32_t depth=0) const;

      // Returns an XML string representation of the object.
      virtual std::string toXML(int32_t depth=0);

      // Returns object type id
      virtual uint32_t getLmcpType(void) const { return TypeId; }
	  
      // Returns object type name string
      virtual std::string getLmcpTypeName(void) const { return TypeName; }
	  
      // Returns object type name string with full namespace prepended, same as subscription name
      virtual std::string getFullLmcpTypeName(void) const { return Subscription; }

      // Returns series name string
      virtual std::string getSeriesName(void) const { return SeriesName; }

      // gets the series name as a long value
      virtual int64_t getSeriesNameAsLong(void) const { return SeriesId; }

      //gets the version number of the series
      virtual uint16_t getSeriesVersion(void) const { return SeriesVersion; }

      // Accessors and Modifiers
      /** Max range that a hazard can be detected (Units: m)*/
      float getMaxRange(void) const { return __MaxRange; }
      HazardSensorConfiguration& setMaxRange(const float val);

      /** Horizontal extents of the sensor (Units: degrees)*/
      float getHorizontalFOV(void) const { return __HorizontalFOV; }
      HazardSensorConfiguration& setHorizontalFOV(const float val);

      /** Vertical extents of the sensor (Units: degrees)*/
      float getVerticalFOV(void) const { return __VerticalFOV; }
      HazardSensorConfiguration& setVerticalFOV(const float val);

      /** Types of hazards that can be detected by this sensor (Units: None)*/
      std::vector<afrl::cmasi::searchai::HazardType::HazardType> & getDetectableHazardTypes(void) { return __DetectableHazardTypes; }



   protected:
      /** Max range that a hazard can be detected */
      float __MaxRange;
      /** Horizontal extents of the sensor */
      float __HorizontalFOV;
      /** Vertical extents of the sensor */
      float __VerticalFOV;
      /** Types of hazards that can be detected by this sensor */
      std::vector< afrl::cmasi::searchai::HazardType::HazardType > __DetectableHazardTypes;

   };

} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl


#endif // _AFRL_CMASI_SEARCHAI_HAZARDSENSORCONFIGURATION_H_
