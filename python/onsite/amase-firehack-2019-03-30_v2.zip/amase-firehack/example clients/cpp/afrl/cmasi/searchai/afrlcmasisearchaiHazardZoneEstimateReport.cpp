// ===============================================================================
// Authors: AFRL/RQQA
// Organization: Air Force Research Laboratory, Aerospace Systems Directorate, Power and Control Division
// 
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

#include <cassert>
#include <sstream>
#include <iomanip>
#include "afrl/cmasi/searchai/HazardZoneEstimateReport.h"
#include "afrl/cmasi/Circle.h"
#include "afrl/cmasi/Polygon.h"
#include "afrl/cmasi/Rectangle.h"


namespace afrl {
namespace cmasi {
namespace searchai {


   // Subscription string is namespace separated by '.' followed by type name
   const std::string HazardZoneEstimateReport::Subscription = "afrl.cmasi.searchai.HazardZoneEstimateReport";
   const std::string HazardZoneEstimateReport::TypeName = "HazardZoneEstimateReport";
   const std::string HazardZoneEstimateReport::SeriesName = "SEARCHAI";
   const int64_t HazardZoneEstimateReport::SeriesId = 6000273900112986441LL;
   const uint16_t HazardZoneEstimateReport::SeriesVersion = 5;
   const uint32_t HazardZoneEstimateReport::TypeId = 3;
   
   bool isHazardZoneEstimateReport(avtas::lmcp::Object* obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 3) return false;
      return true;
   }
   
   bool isHazardZoneEstimateReport(std::shared_ptr<avtas::lmcp::Object>& obj)
   {
      if(!obj) return false;
      if(obj->getSeriesNameAsLong() != 6000273900112986441LL) return false;
      if(obj->getSeriesVersion() != 5) return false;
      if(obj->getLmcpType() != 3) return false;
      return true;
   }
   
   std::vector< std::string > HazardZoneEstimateReportDescendants()
   {
       std::vector< std::string > descendants;
       

       return descendants;
   }
   
   HazardZoneEstimateReport::HazardZoneEstimateReport(void) : avtas::lmcp::Object()
   {
      __UniqueTrackingID = 0;
      __EstimatedZoneShape = new afrl::cmasi::AbstractGeometry();
      __EstimatedGrowthRate = 0.f;
      __PerceivedZoneType = afrl::cmasi::searchai::HazardType::Undefined;
      __EstimatedZoneDirection = 0.f;
      __EstimatedZoneSpeed = 0.f;

   }
     
   HazardZoneEstimateReport::HazardZoneEstimateReport(const HazardZoneEstimateReport &that) : avtas::lmcp::Object(that)
   {
        __UniqueTrackingID = that.__UniqueTrackingID;
        __EstimatedZoneShape = that.__EstimatedZoneShape == nullptr ? nullptr : that.__EstimatedZoneShape->clone();
        __EstimatedGrowthRate = that.__EstimatedGrowthRate;
        __PerceivedZoneType = that.__PerceivedZoneType;
        __EstimatedZoneDirection = that.__EstimatedZoneDirection;
        __EstimatedZoneSpeed = that.__EstimatedZoneSpeed;

   }
   
   HazardZoneEstimateReport & HazardZoneEstimateReport::operator=(const HazardZoneEstimateReport &that)
   {
      if (this != &that)
      {
         avtas::lmcp::Object::operator=(that);
         if (__EstimatedZoneShape != nullptr) delete __EstimatedZoneShape;

         __UniqueTrackingID = that.__UniqueTrackingID;
         __EstimatedZoneShape = that.__EstimatedZoneShape == nullptr ? nullptr : that.__EstimatedZoneShape->clone();
         __EstimatedGrowthRate = that.__EstimatedGrowthRate;
         __PerceivedZoneType = that.__PerceivedZoneType;
         __EstimatedZoneDirection = that.__EstimatedZoneDirection;
         __EstimatedZoneSpeed = that.__EstimatedZoneSpeed;

      }
      return *this;
   }

   HazardZoneEstimateReport* HazardZoneEstimateReport::clone() const
   {
        return new HazardZoneEstimateReport(*this);
   }
   
   HazardZoneEstimateReport::~HazardZoneEstimateReport(void)
   {
      if (__EstimatedZoneShape != nullptr) delete __EstimatedZoneShape;

   }
  
   void HazardZoneEstimateReport::pack(avtas::lmcp::ByteBuffer & buf) const
   {
      // Call parent's pack method
      avtas::lmcp::Object::pack(buf);
      // Copy the class into the buffer
      buf.putUInt(__UniqueTrackingID);
      assert(__EstimatedZoneShape != nullptr);
      avtas::lmcp::Factory::putObject( (avtas::lmcp::Object*) __EstimatedZoneShape, buf);
      buf.putFloat(__EstimatedGrowthRate);
      buf.putInt( (int32_t) __PerceivedZoneType);
      buf.putFloat(__EstimatedZoneDirection);
      buf.putFloat(__EstimatedZoneSpeed);

   }
   
   void HazardZoneEstimateReport::unpack(avtas::lmcp::ByteBuffer & buf)
   {
      // Call parent's unpack method
      avtas::lmcp::Object::unpack(buf);
      // Copy the buffer into the class
      __UniqueTrackingID = buf.getUInt();
      {
         if (__EstimatedZoneShape != nullptr) delete __EstimatedZoneShape;
         __EstimatedZoneShape = nullptr;
         if (buf.getBool())
         {
            int64_t series_id = buf.getLong();
            uint32_t msgtype = buf.getUInt();
            uint16_t version = buf.getUShort();
            __EstimatedZoneShape = (afrl::cmasi::AbstractGeometry*) avtas::lmcp::Factory::createObject( series_id, msgtype, version );
            if (__EstimatedZoneShape != nullptr) __EstimatedZoneShape->unpack(buf);
            else assert(__EstimatedZoneShape != nullptr);
         }
      }
      __EstimatedGrowthRate = buf.getFloat();
      __PerceivedZoneType = (afrl::cmasi::searchai::HazardType::HazardType) buf.getInt();
      __EstimatedZoneDirection = buf.getFloat();
      __EstimatedZoneSpeed = buf.getFloat();

   }

   uint32_t HazardZoneEstimateReport::calculatePackedSize(void) const
   {
      uint32_t size = 0;
      size += avtas::lmcp::Object::calculatePackedSize();
      size += sizeof(uint32_t);
      size += (__EstimatedZoneShape != nullptr ? __EstimatedZoneShape->calculatePackedSize() + 15 : 1);
      size += sizeof(float);
      size += sizeof(afrl::cmasi::searchai::HazardType::HazardType);
      size += sizeof(float);
      size += sizeof(float);

      return size;
   }

   std::string HazardZoneEstimateReport::toString(int32_t depth) const
   {
      std::string indent(depth*3, ' ');
      std::ostringstream oss;
      oss << std::setprecision(15);
      oss << indent << "Object ( HazardZoneEstimateReport ) {\n";
      indent = std::string((++depth)*3, ' ');
      oss << indent << "UniqueTrackingID (uint32_t) = " << __UniqueTrackingID << "\n";
      oss << indent << "EstimatedZoneShape (AbstractGeometry)";
      if (__EstimatedZoneShape == nullptr)
         oss << " = nullptr";
      oss << "\n";
      oss << indent << "EstimatedGrowthRate (float) = " << __EstimatedGrowthRate << "\n";
      oss << indent << "PerceivedZoneType (HazardType) = " << __PerceivedZoneType << "\n";
      oss << indent << "EstimatedZoneDirection (float) = " << __EstimatedZoneDirection << "\n";
      oss << indent << "EstimatedZoneSpeed (float) = " << __EstimatedZoneSpeed << "\n";

      indent = std::string((--depth)*3, ' ');
      oss << indent << "}\n";
      return oss.str();
   }

   std::string HazardZoneEstimateReport::toXML(int32_t depth)
   {
      std::string ws(depth*3, ' ');
      std::ostringstream str;
      str << std::setprecision(15);
      str << ws << "<HazardZoneEstimateReport Series=\"SEARCHAI\">\n";
      str << ws << "   <UniqueTrackingID>" << __UniqueTrackingID << "</UniqueTrackingID>\n";
      if (__EstimatedZoneShape != nullptr)
      {
         str << ws << "   <EstimatedZoneShape>";
         str << "\n" + __EstimatedZoneShape->toXML(depth + 1) + ws + "   ";
         str << "</EstimatedZoneShape>\n";
      }
      str << ws << "   <EstimatedGrowthRate>" << __EstimatedGrowthRate << "</EstimatedGrowthRate>\n";
      str << ws << "   <PerceivedZoneType>" << afrl::cmasi::searchai::HazardType::get_string(__PerceivedZoneType) << "</PerceivedZoneType>\n";
      str << ws << "   <EstimatedZoneDirection>" << __EstimatedZoneDirection << "</EstimatedZoneDirection>\n";
      str << ws << "   <EstimatedZoneSpeed>" << __EstimatedZoneSpeed << "</EstimatedZoneSpeed>\n";
      str << ws << "</HazardZoneEstimateReport>\n";

      return str.str();
   }

   bool HazardZoneEstimateReport::operator==(const HazardZoneEstimateReport & that)
   {
      if( avtas::lmcp::Object::operator!=(that) )
      {
          return false;
      }
      if(__UniqueTrackingID != that.__UniqueTrackingID) return false;
      if(__EstimatedZoneShape && that.__EstimatedZoneShape)
      {
         if(__EstimatedZoneShape->getSeriesNameAsLong() != that.__EstimatedZoneShape->getSeriesNameAsLong()) return false;
         if(__EstimatedZoneShape->getSeriesVersion() != that.__EstimatedZoneShape->getSeriesVersion()) return false;
         if(__EstimatedZoneShape->getLmcpType() != that.__EstimatedZoneShape->getLmcpType()) return false;
         if( *(__EstimatedZoneShape) != *(that.__EstimatedZoneShape) ) return false;
      }
      else if(__EstimatedZoneShape != that.__EstimatedZoneShape) return false;
      if(__EstimatedGrowthRate != that.__EstimatedGrowthRate) return false;
      if(__PerceivedZoneType != that.__PerceivedZoneType) return false;
      if(__EstimatedZoneDirection != that.__EstimatedZoneDirection) return false;
      if(__EstimatedZoneSpeed != that.__EstimatedZoneSpeed) return false;
      return true;

   }

   bool HazardZoneEstimateReport::operator!=(const HazardZoneEstimateReport & that)
   {
      return( !(operator==(that)) );
   }

   HazardZoneEstimateReport& HazardZoneEstimateReport::setUniqueTrackingID(const uint32_t val)
   {
      __UniqueTrackingID = val;
      return *this;
   }

   HazardZoneEstimateReport& HazardZoneEstimateReport::setEstimatedZoneShape(const afrl::cmasi::AbstractGeometry* const val)
   {
      if (__EstimatedZoneShape != nullptr) { delete __EstimatedZoneShape; __EstimatedZoneShape = nullptr; }
      if (val != nullptr) { __EstimatedZoneShape = const_cast< afrl::cmasi::AbstractGeometry* > (val); }
      return *this;
   }

   HazardZoneEstimateReport& HazardZoneEstimateReport::setEstimatedGrowthRate(const float val)
   {
      __EstimatedGrowthRate = val;
      return *this;
   }

   HazardZoneEstimateReport& HazardZoneEstimateReport::setPerceivedZoneType(const afrl::cmasi::searchai::HazardType::HazardType val)
   {
      __PerceivedZoneType = val;
      return *this;
   }

   HazardZoneEstimateReport& HazardZoneEstimateReport::setEstimatedZoneDirection(const float val)
   {
      __EstimatedZoneDirection = val;
      return *this;
   }

   HazardZoneEstimateReport& HazardZoneEstimateReport::setEstimatedZoneSpeed(const float val)
   {
      __EstimatedZoneSpeed = val;
      return *this;
   }


} // end namespace searchai
} // end namespace cmasi
} // end namespace afrl

