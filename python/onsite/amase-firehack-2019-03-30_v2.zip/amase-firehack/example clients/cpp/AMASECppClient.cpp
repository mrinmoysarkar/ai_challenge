// ===============================================================================
// Authors: Jacob Allex-Buckner
// Organization: University of Dayton Research Institute
//
// Copyright (c) 2017 Government of the United State of America, as represented by
// the Secretary of the Air Force.  No copyright is claimed in the United States under
// Title 17, U.S. Code.  All Other Rights Reserved.
// ===============================================================================

// This file was auto-created by LmcpGen. Modifications will be overwritten.

// Utility libraries from standard c++
# ifdef LINUX
#include <arpa/inet.h>
#include <cstring>
#endif
#include <string>
#include <cstdint>
#include <iostream>
#include <vector>

// Include appropriate socket implementation headers.
# ifdef WIN32
#include <winsock.h>
#endif
#define socklen_t int

#include "avtas/lmcp/ByteBuffer.h"
#include "avtas/lmcp/Factory.h"
#include "avtas/lmcp/Object.h"
#include "afrl/cmasi/CMASI.h"


# ifdef LINUX
typedef int SOCKET;
int SOCKET_ERROR = -1;  // error return code for socket()
int INVALID_SOCKET = -1;  // error return code for connect()
#endif

bool EstablishConnection(SOCKET&, int, std::string&);
void sendMissionCommand(SOCKET);
void sendSensorCommand(SOCKET);
void sendLoiterCommand(SOCKET);
void readMessages(avtas::lmcp::Object*);
int64_t scenarioTime = 0;

bool EstablishConnection(SOCKET& connectionSocket, int port, std::string& host)
{
# ifdef WIN32
	// Start Winsock
	WSAData wsaData;
	WSAStartup(MAKEWORD(1, 1), &wsaData);
#endif

	connectionSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (connectionSocket == INVALID_SOCKET)
		return false;
	sockaddr_in source;
	source.sin_family = AF_INET;
	source.sin_addr.s_addr = inet_addr(host.c_str());
	source.sin_port = htons((u_short)port);
	memset(&(source.sin_zero), '\0', 8);
	socklen_t source_len = sizeof(source);
	if (connect(connectionSocket, (sockaddr*)&source, source_len) == SOCKET_ERROR)
	{
		return false;
	}
	std::cout << "Connection established..." << std::endl;
	return true;
}

void sendMissionCommand(SOCKET sock)
{
	// send out all of messages
	avtas::lmcp::ByteBuffer* sendBuf = nullptr;
	uint8_t* pBuf = nullptr;

	// Setting up the mission to send to the UAV
	afrl::cmasi::MissionCommand* _afrlcmasimissioncommand = new afrl::cmasi::MissionCommand();
	_afrlcmasimissioncommand->setFirstWaypoint(1);
	// Setting the UAV to recieve the mission
	_afrlcmasimissioncommand->setVehicleID(1);
	_afrlcmasimissioncommand->setStatus(afrl::cmasi::CommandStatusType::CommandStatusType::Pending);
	// Setting a unique mission command ID
	_afrlcmasimissioncommand->setCommandID(1);
	//Creating the list of waypoints to be sent with the mission command
	std::vector<afrl::cmasi::Waypoint>* _afrlcmasiwaypoints = new std::vector<afrl::cmasi::Waypoint>();
	// Creating the first waypoint
	// Note: all the following attributes must be set to avoid issues
	afrl::cmasi::Waypoint* _afrlcmasiwaypoint1 = new afrl::cmasi::Waypoint();
	// Setting 3D coordinates
	_afrlcmasiwaypoint1->setLatitude(1.505);
	_afrlcmasiwaypoint1->setLongitude(-132.539);
	_afrlcmasiwaypoint1->setAltitude(100);
	_afrlcmasiwaypoint1->setAltitudeType(afrl::cmasi::AltitudeType::AltitudeType::MSL);
	// Setting unique ID for the waypoint
	_afrlcmasiwaypoint1->setNumber(1);
	_afrlcmasiwaypoint1->setNextWaypoint(2);
	// Setting speed to reach the waypoint
	_afrlcmasiwaypoint1->setSpeed(30);
	_afrlcmasiwaypoint1->setSpeedType(afrl::cmasi::SpeedType::SpeedType::Airspeed);
	// Setting the climb rate to reach new altitude (if applicable)
	_afrlcmasiwaypoint1->setClimbRate(0);
	_afrlcmasiwaypoint1->setTurnType(afrl::cmasi::TurnType::TurnType::TurnShort);
	// Setting backup waypoints if new waypoint can't be reached
	_afrlcmasiwaypoint1->setContingencyWaypointA(0);
	_afrlcmasiwaypoint1->setContingencyWaypointB(0);

	// Setting up the second waypoint to be sent in the mission command
	afrl::cmasi::Waypoint* _afrlcmasiwaypoint2 = new afrl::cmasi::Waypoint();
	_afrlcmasiwaypoint2->setLatitude(1.52);
	_afrlcmasiwaypoint2->setLongitude(-132.51);
	_afrlcmasiwaypoint2->setAltitude(100);
	_afrlcmasiwaypoint2->setAltitudeType(afrl::cmasi::AltitudeType::AltitudeType::MSL);
	_afrlcmasiwaypoint2->setNumber(2);
	_afrlcmasiwaypoint2->setNextWaypoint(1);
	_afrlcmasiwaypoint2->setSpeed(30);
	_afrlcmasiwaypoint2->setSpeedType(afrl::cmasi::SpeedType::SpeedType::Airspeed);
	_afrlcmasiwaypoint2->setClimbRate(0);
	_afrlcmasiwaypoint2->setTurnType(afrl::cmasi::TurnType::TurnType::TurnShort);
	_afrlcmasiwaypoint2->setContingencyWaypointA(0);
	_afrlcmasiwaypoint2->setContingencyWaypointB(0);

	// Adding the waypoints to the waypoint list
	_afrlcmasimissioncommand->getWaypointList().push_back(_afrlcmasiwaypoint1);
	_afrlcmasimissioncommand->getWaypointList().push_back(_afrlcmasiwaypoint2);

	// Sending the Mission Command message to AMASE to be interpreted
	sendBuf = avtas::lmcp::Factory::packMessage(_afrlcmasimissioncommand, true);
	delete _afrlcmasimissioncommand;
	delete _afrlcmasiwaypoint1;
	delete _afrlcmasiwaypoint2;
	pBuf = sendBuf->array();
	send(sock, (char*)pBuf, sendBuf->position(), 0);
	delete sendBuf;
}

void sendSensorCommand(SOCKET sock)
{
	// send out all of messages
	avtas::lmcp::ByteBuffer* sendBuf = nullptr;
	uint8_t* pBuf = nullptr;

	// Setting up the mission to send to the UAV
	afrl::cmasi::VehicleActionCommand* _afrlcmasivehicleactioncommand = new afrl::cmasi::VehicleActionCommand();
	_afrlcmasivehicleactioncommand->setVehicleID(1);
	_afrlcmasivehicleactioncommand->setStatus(afrl::cmasi::CommandStatusType::CommandStatusType::Pending);
	_afrlcmasivehicleactioncommand->setCommandID(1);

	// Setting up the vehicle action command list
	std::vector<afrl::cmasi::VehicleAction>* vehicleActionList = new std::vector<afrl::cmasi::VehicleAction>();

	// Setting up the gimbal stare vehicle action
	afrl::cmasi::GimbalStareAction* _afrlcmasigimbalstareaction = new afrl::cmasi::GimbalStareAction();
	_afrlcmasigimbalstareaction->setPayloadID(1);
	_afrlcmasigimbalstareaction->setDuration(1000000);

	// Creating a 3D location object for the stare point
	afrl::cmasi::Location3D* _afrlcmasilocation = new afrl::cmasi::Location3D();
	_afrlcmasilocation->setLatitude(1.52);
	_afrlcmasilocation->setLongitude(-132.51);
	_afrlcmasilocation->setAltitude(0);
	_afrlcmasilocation->setAltitudeType(afrl::cmasi::AltitudeType::AltitudeType::MSL);
	_afrlcmasigimbalstareaction->setStarepoint(_afrlcmasilocation);

	// Adding the gimbal stare action to the vehicle action list
	vehicleActionList->push_back(*_afrlcmasigimbalstareaction);

	// Sending the Vehicle Action Command messag to AMASE to be interpreted
	sendBuf = avtas::lmcp::Factory::packMessage(_afrlcmasivehicleactioncommand, true);
	delete _afrlcmasivehicleactioncommand;
	delete _afrlcmasigimbalstareaction;
	delete _afrlcmasilocation;
	pBuf = sendBuf->array();
	send(sock, (char*)pBuf, sendBuf->position(), 0);
	delete sendBuf;
}

void sendLoiterCommand(SOCKET sock)
{
	// send out all of messages
	avtas::lmcp::ByteBuffer* sendBuf = nullptr;
	uint8_t* pBuf = nullptr;

	// Setting up the mission to send to the UAV
	afrl::cmasi::VehicleActionCommand* _afrlcmasivehicleactioncommmand = new afrl::cmasi::VehicleActionCommand();
	_afrlcmasivehicleactioncommmand->setVehicleID(1);
	_afrlcmasivehicleactioncommmand->setStatus(afrl::cmasi::CommandStatusType::CommandStatusType::Pending);
	_afrlcmasivehicleactioncommmand->setCommandID(1);

	// Setting up the loiter action
	afrl::cmasi::LoiterAction* _afrlcmasiloiteraction = new afrl::cmasi::LoiterAction();
	_afrlcmasiloiteraction->setLoiterType(afrl::cmasi::LoiterType::LoiterType::Circular);
	_afrlcmasiloiteraction->setRadius(500);
	_afrlcmasiloiteraction->setAxis(0);
	_afrlcmasiloiteraction->setLength(0);
	_afrlcmasiloiteraction->setDirection(afrl::cmasi::LoiterDirection::LoiterDirection::Clockwise);
	_afrlcmasiloiteraction->setDuration(1000000);
	_afrlcmasiloiteraction->setAirspeed(30);

	// Creating a 3D location object for the stare point
	afrl::cmasi::Location3D* _afrlcmasilocation = new afrl::cmasi::Location3D();
	_afrlcmasilocation->setLatitude(1.52);
	_afrlcmasilocation->setLongitude(-132.51);
	_afrlcmasilocation->setAltitude(0);
	_afrlcmasilocation->setAltitudeType(afrl::cmasi::AltitudeType::AltitudeType::MSL);
	_afrlcmasiloiteraction->setLocation(_afrlcmasilocation);

	// Adding the loiter actio to the vehicle action list
	_afrlcmasivehicleactioncommmand->getVehicleActionList().push_back(_afrlcmasiloiteraction);

	// Sending the Vehicle Action command message to AMASE to be interpreted
	sendBuf = avtas::lmcp::Factory::packMessage(_afrlcmasivehicleactioncommmand, true);
	delete _afrlcmasivehicleactioncommmand;
	delete _afrlcmasiloiteraction;
	pBuf = sendBuf->array();
	send(sock, (char*)pBuf, sendBuf->position(), 0);
	delete sendBuf;
}

void readMessages(avtas::lmcp::Object* obj)
{
	if (!obj)
	{
		std::cout << "Invalid message format" << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::AbstractGeometry::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::KeyValuePair::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::Location3D::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::PayloadAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::PayloadConfiguration::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::PayloadState::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::VehicleAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::Task::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::SearchTask::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::AbstractZone::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::EntityConfiguration::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::FlightProfile::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::AirVehicleConfiguration::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::EntityState::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::AirVehicleState::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::Wedge::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::AreaSearchTask::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::CameraAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::CameraConfiguration::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::GimballedPayloadState::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::CameraState::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::Circle::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::GimbalAngleAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::GimbalConfiguration::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::GimbalScanAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::GimbalStareAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::GimbalState::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::GoToWaypointAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::KeepInZone::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::KeepOutZone::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::LineSearchTask::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::NavigationAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::LoiterAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::LoiterTask::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::Waypoint::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::MissionCommand::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::MustFlyTask::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::OperatorSignal::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::OperatingRegion::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::AutomationRequest::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::PointSearchTask::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::Polygon::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::Rectangle::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::RemoveTasks::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::ServiceStatus::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::SessionStatus::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
		//Example of using an incoming LMCP message
		scenarioTime = dynamic_cast<afrl::cmasi::SessionStatus*>(obj)->getScenarioTime();
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::VehicleActionCommand::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::VideoStreamAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::VideoStreamConfiguration::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::VideoStreamState::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::AutomationResponse::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::RemoveZones::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::RemoveEntities::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::FlightDirectorAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::WeatherReport::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::FollowPathCommand::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::PathWaypoint::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::StopMovementAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::WaypointTransfer::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else if ((obj->getLmcpTypeName()) == afrl::cmasi::PayloadStowAction::TypeName)
	{
		std::cout << obj->getLmcpTypeName() << std::endl;
	}
	else
	{
		//Don't do anything if the message isn't for AMASE
		std::cout << "Could not read byte" << std::endl;
	}
}

// Define the main method.
int main(int argc, char* argv[])
{
	int port = 5555;
	std::string host = "127.0.0.1";

	// create connection
	SOCKET connectionSocket;
	while (!EstablishConnection(connectionSocket, port, host))
	{
		std::cout << "Could not establish connection!" << std::endl;
	}

	// Create the buffer to hold incoming messages. Choosing an arbitrarily large sized
	// buffer big enough to hold any message we want to receive.
	uint32_t bufferSize = 1048576;
	char* buffer = new char[bufferSize];

	// Flags for sending commands
	bool missionCommandSent = false;
	bool sensorCommandSent = false;
	bool loiterCommandSent = false;
	long scenarioTime = 0;

	// display any messages coming across network
	avtas::lmcp::ByteBuffer buf;
	for (;;)
	{
		// Read messages
		int bytesReceived = recv(connectionSocket, buffer, bufferSize, 0);

		if (bytesReceived <= 0)
		{
			std::cout << "Connection closed or message receive error. Reconnecting ..." << std::endl;
			while (!EstablishConnection(connectionSocket, port, host))
			{
				std::cout << "Could not establish connection!" << std::endl;
			}
			continue;
		}

		// potentially received multiple messages back-to-back
		int offsetindex = 0;
		while (bytesReceived > static_cast<int>(avtas::lmcp::Factory::HEADER_SIZE))
		{
			uint8_t* startByte = (uint8_t*)&buffer[offsetindex];
			uint32_t objsize = avtas::lmcp::Factory::getObjectSize(startByte, avtas::lmcp::Factory::HEADER_SIZE);
			objsize += avtas::lmcp::Factory::HEADER_SIZE + avtas::lmcp::Factory::CHECKSUM_SIZE;

			// process message
			buf.allocate(objsize);
			buf.rewind();
			memcpy(buf.array(), startByte, objsize);
			bytesReceived -= objsize;
			offsetindex += objsize;
			avtas::lmcp::Object* obj = avtas::lmcp::Factory::getObject(buf);
			if (!obj)
			{
				std::cout << "Invalid message format" << std::endl;
				continue;
			}
			readMessages(obj);
			delete obj;

			// Send messages
			if (scenarioTime >= 15000 && missionCommandSent == false)
			{
				// Send a message to change the 1st entity's waypoint
				sendMissionCommand(connectionSocket);
				missionCommandSent = true;
			}
			if (scenarioTime >= 40000 && sensorCommandSent == false)
			{
				sendSensorCommand(connectionSocket);
				sensorCommandSent = true;
			}
			if (scenarioTime >= 100000 && loiterCommandSent == false)
			{
				sendLoiterCommand(connectionSocket);
				loiterCommandSent = true;
			}
			continue;

		}
	}
}